ReachoMeter - Fabric 1.21.11

This project includes the source files and Gradle build configuration.
To build the actual mod JAR, install Java 21 and Gradle, open this folder in a terminal,
then run:

    gradle build

The compiled mod will be in build/libs/.

This environment could not compile the JAR because Gradle and the Fabric/Minecraft
dependency caches are not installed and internet access is unavailable. The ZIP is
a build-ready project, not a compiled mod JAR.
